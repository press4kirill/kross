package com.kirill.krossovertest;

import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.kirill.krossovertest.fragments.HeadlessFragment;
import com.kirill.krossovertest.utils.SensorMenu;

import static com.kirill.krossovertest.Controller.isNetworkAvailable;
import static com.kirill.krossovertest.utils.Provider.CONTENT_URI;


public class MainActivity extends AppCompatActivity implements SensorMenu.SensorMenuEventConsumer {


    private HeadlessFragment mFragment;
    private Controller mController;
    private SensorMenu mSensorMenu;
    public static int SCROLL_BY = 0;

    public static final String NETWORK_UNAVAILABLE = "Sorry, network unavaliable";
    public static final String FLICKER_URL = "https://api.flickr.com";
    public static String FLICKER_API_KEY = "";
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FLICKER_API_KEY = getFlickrAPIKey();
        FragmentManager mMgr = getFragmentManager();
        mFragment = (HeadlessFragment) mMgr
                .findFragmentByTag(HeadlessFragment.TAG_HEADLESS_FRAGMENT);

        if (mFragment == null) {
            mFragment = new HeadlessFragment();
            mMgr.beginTransaction()
                    .add(mFragment, HeadlessFragment.TAG_HEADLESS_FRAGMENT)
                    .commit();
        }
        getLoaderManager(); //Weird bug https://stackoverflow.com/questions/12507617/android-loader-not-triggering-callbacks-on-screen-rotate
        mController = new Controller(this, mFragment, (LinearLayout) findViewById(R.id.main_activity_view));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem menuItem = menu.findItem(R.id.menu_sensor);
        if (menuItem != null)
            menuItem.setTitle(SensorMenu.ACTIVATED ? "Disable sensor" : "Activate sensor");
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.menu_reload:
                if (mFragment.getIfTaskInProgress() ) {
                    Toast.makeText(this, "Wait, still loading...", Toast.LENGTH_SHORT).show();
                    return true;
                }
                if (!isNetworkAvailable(this)) {
                    Toast.makeText(this, NETWORK_UNAVAILABLE, Toast.LENGTH_SHORT).show();
                    return true;
                }

                mController.loadNewBatch();
                return true;

            case R.id.menu_sensor:

                SensorMenu.ACTIVATED = !SensorMenu.ACTIVATED;
                Toast.makeText(this, SensorMenu.ACTIVATED ? "Sensor enabled" : "Sensor disabled", Toast.LENGTH_SHORT).show();
                item.setTitle(SensorMenu.ACTIVATED ? "Disable sensor" : "Activate sensor");
                mSensorMenu.setSensorMenuEventConsumer(SensorMenu.ACTIVATED ? this : null);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        SCROLL_BY = metrics.heightPixels * 3 / 5;
        mSensorMenu = new SensorMenu(this);
        mController.onMainActivityResume();

    }

    @Override
    public void onPause() {
        super.onPause();
        mController.onMainActivityPause();
        mSensorMenu.setSensorMenuEventConsumer(null);
        mSensorMenu = null;
    }

    public void onDownloadError(String err) {
        mController.onDownloadError(err);
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */

    public  native String getFlickrAPIKey();


    @Override
    public void onPitchUp() {
        mController.onPitchUp();
    }

    @Override
    public void onPitchDown() {
        mController.onPitchDown();
    }
}
