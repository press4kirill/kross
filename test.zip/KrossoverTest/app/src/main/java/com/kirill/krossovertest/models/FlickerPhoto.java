package com.kirill.krossovertest.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * Created by Administrator on 6/4/2017.
 */


public class FlickerPhoto {
    @SerializedName("photos")
    public Photos mPhotos;

    @SerializedName("stat")
    public String mStat;

    public static class Photos {
        @SerializedName("pages")
        public Integer mPages;

        @SerializedName("photo")
        public List<Photo> mPhotoList;
    }
}
