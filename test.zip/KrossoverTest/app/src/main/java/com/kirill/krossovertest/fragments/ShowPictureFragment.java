package com.kirill.krossovertest.fragments;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;

import com.kirill.krossovertest.R;

/**
 * Created by Administrator on 6/4/2017.
 */

public class ShowPictureFragment extends DialogFragment {
    private Bitmap mBitmap;
    private ImageView mImageView;

    public void setImage(Bitmap bitmap) {
        mBitmap = bitmap;
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_picture, container, false);
        ((Button)view.findViewById(R.id.button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        mImageView = (ImageView)view.findViewById(R.id.picture);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        final DisplayMetrics displayMetrics = new DisplayMetrics();

        // Retrieves a displayMetrics object for the device's default display
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        final int height = displayMetrics.heightPixels;
        final int width = displayMetrics.widthPixels;

        int dim = height > width ? width : height;
        getDialog().getWindow().setLayout(dim, dim);

        if (mBitmap != null) {
            mImageView.setImageBitmap(mBitmap);
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        return dialog;
    }
}