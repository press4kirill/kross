package com.kirill.krossovertest.utils;


import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.j256.ormlite.android.apptools.OpenHelperManager;

public class Provider extends ContentProvider {
	private static final int PHOTOS=1;
	private static final UriMatcher MATCHER;

	public static final Uri CONTENT_URI =  Uri.parse("content://com.kirill.krossovertest.test.Provider/photos");
	
	static {
	  MATCHER=new UriMatcher(UriMatcher.NO_MATCH);
	  MATCHER.addURI("com.kirill.krossovertest.test.Provider", "photos", PHOTOS);
	}

	@Override
	public String getType(Uri notUsed) {
		return null;
	}
	
	@Override
	public Uri insert(Uri url, ContentValues initialValues) {
	 return null;
	}
	
	@Override
	public int delete(Uri url, String where, String[] whereArgs) {
		return -1;
	}
	
	@Override
	public int update(Uri url, ContentValues values, String where,  String[] whereArgs) {
		return -1;
	}
	
	@Override
	public boolean onCreate() {
		return true;
	}

	@Override
	public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
		Cursor cursor = OpenHelperManager.getHelper(getContext(), DatabaseHelper.class).loadPhotos();
		cursor.setNotificationUri(getContext().getContentResolver(), Provider.CONTENT_URI);
		return cursor;
	}
}