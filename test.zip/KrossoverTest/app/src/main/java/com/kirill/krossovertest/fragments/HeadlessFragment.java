package com.kirill.krossovertest.fragments;

/**
 * Created by Administrator on 6/4/2017.
 */
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.Callable;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;


import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.misc.TransactionManager;
import com.kirill.krossovertest.MainActivity;
import com.kirill.krossovertest.models.FlickerPhoto;
import com.kirill.krossovertest.models.Photo;
import com.kirill.krossovertest.utils.DatabaseHelper;

import retrofit.RestAdapter;
import retrofit.http.GET;
import retrofit.http.Query;
import static com.kirill.krossovertest.MainActivity.FLICKER_API_KEY;
import static com.kirill.krossovertest.utils.Provider.CONTENT_URI;


public class HeadlessFragment extends Fragment {

    public static final String TAG_HEADLESS_FRAGMENT = "headless_fragment";
    public interface FlickerPhotoInterface {
        @GET("/services/rest/?method=flickr.photos.search&format=json&nojsoncallback=1&text=cat&extras=url_s")
        FlickerPhoto getPhotos(@Query("api_key") String address);
    }

    private BackgroundTask mBackgroundTask;
    private boolean isTaskExecuting = false;
    public boolean getIfTaskInProgress() {
        return isTaskExecuting;
    }

    /**
     * Called to do initial creation of a fragment.
     * This is called after onAttach(Activity) and before onCreateView(LayoutInflater, ViewGroup, Bundle)
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRetainInstance(true);

    }

    private static class BackgroundTask extends AsyncTask<Void, Void, Void> {

        final private WeakReference<HeadlessFragment> mHeadlessFragment;
        final private Context mContext;
        boolean mSuccess = false;

        @Override
        protected Void doInBackground(Void ... notused) {

            try {

                RestAdapter retrofit = new RestAdapter.Builder().setEndpoint(MainActivity.FLICKER_URL).build();
                FlickerPhotoInterface all = retrofit.create(FlickerPhotoInterface.class);
                final FlickerPhoto ff =  all.getPhotos(FLICKER_API_KEY);
                final DatabaseHelper helper = OpenHelperManager.getHelper(mContext, DatabaseHelper.class);
                final Dao<Photo, Integer> photoDao = helper.getPhotoDao();
                mSuccess = "ok".equals(ff.mStat);
                if (!mSuccess)
                    return null;
                helper.clearDB();

                TransactionManager.callInTransaction(helper.getConnectionSource(),
                        new Callable<Void>() {
                            public Void call() throws Exception {
                                for (Photo photo :  ff.mPhotos.mPhotoList) {
                                    photoDao.create(photo);
                                }
                               // helper.commit();
                                mContext.getContentResolver().notifyChange(CONTENT_URI, null);

                                return null;
                            }
                });

            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            if (mHeadlessFragment != null && mHeadlessFragment.get() != null)
                mHeadlessFragment.get().updateExecutingStatus(false);
            if (!mSuccess) {
                ((MainActivity)mContext).onDownloadError("Download failed, please try later");
            }
        }

        public BackgroundTask(HeadlessFragment hf) {

            mHeadlessFragment = new WeakReference<HeadlessFragment>(hf);
            mContext = hf.getActivity();
        }

    }

    public void startBackgroundTask() {

        if(!isTaskExecuting){
            mBackgroundTask = new BackgroundTask(this);
            mBackgroundTask.execute();
            isTaskExecuting = true;
        }
    }

    /* Not used
    public void cancelBackgroundTask() {
        if(isTaskExecuting){
            mBackgroundTask.cancel(true);
            isTaskExecuting = false;
        }
    }
*/
    private void updateExecutingStatus(boolean isExecuting){
        isTaskExecuting = isExecuting;
        mBackgroundTask = null;
        System.gc(); // humbly asking the system to cleanup ...garbage collecting...union job...probably won't do it :)
    }

}
