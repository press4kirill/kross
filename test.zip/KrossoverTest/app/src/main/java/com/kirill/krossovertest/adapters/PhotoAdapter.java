package com.kirill.krossovertest.adapters;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kirill.krossovertest.R;
import com.kirill.krossovertest.fragments.ShowPictureFragment;
import com.kirill.krossovertest.models.Photo;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;



import static android.content.Context.CONNECTIVITY_SERVICE;
import static com.kirill.krossovertest.Controller.isNetworkAvailable;
import static com.kirill.krossovertest.MainActivity.NETWORK_UNAVAILABLE;

/**
 * Created by Administrator on 6/4/2017.
 */


public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.PhotoHolder> {

    public class PhotoHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        final private TextView mPhotoTitleTextView;
        final private TextView mPhotoSizeTextView;
        final private RelativeLayout mBkg;
        private Photo mPhoto;

        public PhotoHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

            mPhotoTitleTextView = (TextView) itemView.findViewById(R.id.photo_title);
            mPhotoSizeTextView = (TextView) itemView.findViewById(R.id.photo_size);
            mBkg = (RelativeLayout) itemView.findViewById(R.id.photo_bkg);
        }

        public void bindPhoto(Photo photo, int position) {
            mPhoto = photo;

            mPhotoTitleTextView.setText(mPhoto.title);

            //      mPhotoTitleTextView.setText(new SpannableString(Html.fromHtml(mPhoto.mTitle)));
            mPhotoSizeTextView.setText("Size " + mPhoto.height + "x" + mPhoto.width);

            mBkg.setBackgroundColor(((position % 2) == 0) ? Color.LTGRAY : Color.WHITE);
        }

        @Override
        public void onClick(View v) {

            Context context = v.getContext();
            if (!isNetworkAvailable(context)) {
                Toast.makeText( context, NETWORK_UNAVAILABLE, Toast.LENGTH_SHORT).show();
                return;
            }
            if (mIsTaskExecuting)
                return;
            mIsTaskExecuting = true;
            new FetchPhotoTask(((AppCompatActivity) context).getSupportFragmentManager(), mPhoto.url).execute();
        }
    }


    final private List<Photo> mPhotos;
    final private LayoutInflater mLayoutInflater;
    private boolean mIsTaskExecuting = false;

    public PhotoAdapter(List<Photo> photos, LayoutInflater layoutInflater) {
        mPhotos = photos;
        mLayoutInflater = layoutInflater;
    }

    @Override
    public PhotoHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = mLayoutInflater.inflate(R.layout.list_item_photo, parent, false);

        return new PhotoHolder(view);
    }

    @Override
    public void onBindViewHolder(PhotoHolder holder, int position) {
        Photo photo = mPhotos.get(position);
        holder.bindPhoto(photo, position);
    }

    @Override
    public int getItemCount() {
        return mPhotos == null ? 0 : mPhotos.size();
    }

    private class FetchPhotoTask extends AsyncTask<Void, Void, Void> {
        private Bitmap mBitmap;
        final private FragmentManager mManager;
        final private String mUrl;


        public FetchPhotoTask(FragmentManager manager, String url) {
            mManager = manager;
            mUrl = url;
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                URL url = new URL(mUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                mBitmap = BitmapFactory.decodeStream(input);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void p) {
            try {
                final ShowPictureFragment dialog = new ShowPictureFragment();
                dialog.setImage(mBitmap);
                dialog.show(mManager, "");
                mIsTaskExecuting = false;
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

}

