package com.kirill.krossovertest.utils;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class SensorMenu implements SensorEventListener {
	
	private SensorManager mgr;
	private Sensor accelerometer;
	    
	private float[] mGravity;
	private float[] mGeomagnetic;
	private double azimuth, pitch, roll, rollprev, pitchprev;
	
	private float[] mags = new float[3];
	private float[] accels = new float[3];
	private float[] rotationMat = new float[9];
	private float[] inclinationMat = new float[9];
	private float[] attitude = new float[3];
	private final static double RAD2DEG = 180/Math.PI;

	
	public SensorMenu(Context context)
	{
		ACTIVATED = false;
	    mgr = (SensorManager) context.getSystemService(context.SENSOR_SERVICE); 
        
        accelerometer = mgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        mgr.registerListener(this,
        		mgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
        		SensorManager.SENSOR_DELAY_GAME);
        mgr.registerListener(this,
        		mgr.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
        				SensorManager.SENSOR_DELAY_GAME);
        
       
	}
	public void setSensorMenuEventConsumer(SensorMenuEventConsumer sensorMenuEventConsumer) {
		 mSensorMenuEventConsumer = sensorMenuEventConsumer;
	}
	private boolean mReport = false;
	public static boolean ACTIVATED = false;
	public interface SensorMenuEventConsumer {
		 void onPitchUp();
		 void onPitchDown();
	}
	private SensorMenuEventConsumer mSensorMenuEventConsumer;
	@Override
	public void onSensorChanged(SensorEvent event)
	{
		if (ACTIVATED == false) {
			mReport = false;
			return;
		}
		int type = event.sensor.getType();
		if(type == Sensor.TYPE_MAGNETIC_FIELD) {
			mags = event.values;
		}
		if(type == Sensor.TYPE_ACCELEROMETER) {
			accels = event.values;
		}
		SensorManager.getRotationMatrix(rotationMat,inclinationMat, accels, mags);
		SensorManager.getOrientation(rotationMat, attitude);
		
		roll = attitude[2]*RAD2DEG;
		pitch = attitude[1]*RAD2DEG;
		if (Math.abs(rollprev - roll)  > 5) {
			rollprev = roll;
		}
		
		if (-20 < pitch && pitch < 10  ) {
			mReport = true;
			return; 
		}
		if (Math.abs(pitchprev - pitch)  > 5) {
			pitchprev = pitch;
			if (pitch < -50) {
				if (mReport) {
					mReport = false;
					if (mSensorMenuEventConsumer != null) {
						mSensorMenuEventConsumer.onPitchUp();
					}
				}
			}
			else if (pitch > 20) {
				if (mReport) {
					mReport = false;
					if (mSensorMenuEventConsumer != null) {
						mSensorMenuEventConsumer.onPitchDown();
					}
				}
			}
		}
		else if (pitch < 1) {
			
		}
	}
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}
}
