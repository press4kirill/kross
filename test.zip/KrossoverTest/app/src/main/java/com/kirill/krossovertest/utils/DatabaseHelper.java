package com.kirill.krossovertest.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

import com.kirill.krossovertest.R;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.kirill.krossovertest.models.Photo;


public class DatabaseHelper extends OrmLiteSqliteOpenHelper {

    private static final String TABLE_NAME = "photo";
    public static final String[] PROJECTION = new String[]{
            DatabaseHelper.COLUMN_TITLE,
            DatabaseHelper.COLUMN_URL,
            DatabaseHelper.COLUMN_HEIGHT,
            DatabaseHelper.COLUMN_WIDTH
    };

    public final static String COLUMN_TITLE =  "title";
    public final static String COLUMN_URL =    "url";
    public final static String COLUMN_HEIGHT = "height";
    public final static String COLUMN_WIDTH =  "width";

    private static final String DATABASE_NAME = "photos.db";
    private static final int DATABASE_VERSION = 1;

    private Dao<Photo, Integer> photoDao = null;

    public DatabaseHelper(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION, R.raw.ormlite_config);
    }

    @Override
    public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
        try {
            TableUtils.createTable(connectionSource, Photo.class);
         } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, ConnectionSource connectionSource, int oldVersion, int newVersion) {
        // Nothing here
    }

    public Dao<Photo, Integer> getPhotoDao() throws SQLException {
        if(photoDao == null) {
            photoDao = getDao(Photo.class);
        }
        return photoDao;
    }

    public void clearDB() {

        try {
            getPhotoDao().updateRaw("DELETE FROM " + TABLE_NAME);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void commit() {
        getWritableDatabase().setTransactionSuccessful();
    }

    public Cursor loadPhotos() {
        // Returning raw Cursor here for the ContentProvider's benefit
        try {
            return (getWritableDatabase().rawQuery("SELECT * FROM " + TABLE_NAME, null));
        }
        catch (Exception e) {
            return null;
        }
    }
}
