package com.kirill.krossovertest;


import android.content.Context;
import android.database.Cursor;
import android.app.LoaderManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.CursorLoader;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.kirill.krossovertest.adapters.PhotoAdapter;
import com.kirill.krossovertest.fragments.HeadlessFragment;
import com.kirill.krossovertest.models.Photo;
import com.kirill.krossovertest.utils.DatabaseHelper;
import com.kirill.krossovertest.utils.Provider;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;
import static com.kirill.krossovertest.MainActivity.NETWORK_UNAVAILABLE;
import static com.kirill.krossovertest.utils.DatabaseHelper.PROJECTION;

/**
 * Created by Administrator on 6/4/2017.
 */

public class Controller implements LoaderManager.LoaderCallbacks<Cursor> {
    final private MainActivity mMainActivity;
    final private HeadlessFragment mHeadlessFragment;
    final private RecyclerView mMoviesRecyclerView;
    final private LinearLayout mLoading;
    final private TextView mHeaderTextView;


    public Controller(MainActivity ma, HeadlessFragment hf, View view) {
        mMainActivity = ma;
        mHeadlessFragment = hf;

        mMoviesRecyclerView = (RecyclerView) view.findViewById(R.id.photos_recycler_view);
        mLoading = (LinearLayout) view.findViewById(R.id.loading);
        mHeaderTextView = (TextView)view.findViewById(R.id.header_tv);
        mMoviesRecyclerView.setLayoutManager(new LinearLayoutManager(mMainActivity));

        mMoviesRecyclerView.setVisibility(View.GONE);
        mHeaderTextView.setVisibility(View.GONE);
        mLoading.setVisibility(View.GONE);
    }
    protected void hideHeader() {
        mMoviesRecyclerView.setVisibility(View.GONE);
        mHeaderTextView.setVisibility(View.GONE);
        mLoading.setVisibility(View.VISIBLE);
    }
    protected void showHeader(String header) {
        mMoviesRecyclerView.setVisibility(View.VISIBLE);
        mHeaderTextView.setVisibility(View.VISIBLE);
        mHeaderTextView.setText(header);
        mLoading.setVisibility(View.GONE);
    }
    public void onDownloadError(String err) {
        mMoviesRecyclerView.setVisibility(View.GONE);
        mHeaderTextView.setVisibility(View.VISIBLE);
        mHeaderTextView.setText(err);
        mLoading.setVisibility(View.GONE);
    }
    public void onMainActivityResume() {
        mMainActivity.getLoaderManager().initLoader(0, null, this);
    }

    public void loadNewBatch() {
        OpenHelperManager.getHelper(mMainActivity, DatabaseHelper.class).clearDB();
        mMainActivity.getLoaderManager().restartLoader(0, null, this);
    }

    public void onMainActivityPause() {
        mMainActivity.getLoaderManager().destroyLoader(0);
    }

    public void onPitchUp() {
        mMoviesRecyclerView.smoothScrollBy(0, -MainActivity.SCROLL_BY);
    }

    public void onPitchDown() {
        mMoviesRecyclerView.smoothScrollBy(0, MainActivity.SCROLL_BY);
    }

    @Override
    public android.content.Loader<Cursor> onCreateLoader(int id, Bundle args) {

        return(new CursorLoader(mMainActivity, Provider.CONTENT_URI,  PROJECTION, null, null, null));
    }
    private boolean mGotFromNet = false;
    @Override
    public void onLoadFinished(android.content.Loader<Cursor> loader,Cursor cursor) {

        boolean isNetAvailable = isNetworkAvailable(mMainActivity);
        if (cursor != null && cursor.getCount() > 1) {
            showHeader(mGotFromNet ? "Loaded From The Internet" : "Loaded From Local SQLite");
            mGotFromNet = false;
            showAllPhotos(cursor);
        }
        else {
            if (!isNetAvailable) {
                showHeader(NETWORK_UNAVAILABLE);
                return;
            }
            hideHeader();
            if (mHeadlessFragment != null && isNetworkAvailable(mMainActivity)) {
                mGotFromNet = true;
                mHeadlessFragment.startBackgroundTask();
            }
        }
    }

    private void showAllPhotos(Cursor cursor){
        int titleIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_TITLE);
        int heightIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_HEIGHT);
        int widthIndex =  cursor.getColumnIndex(DatabaseHelper.COLUMN_WIDTH);
        int urlIndex =  cursor.getColumnIndex(DatabaseHelper.COLUMN_URL);
        List<Photo> allPhotos = new ArrayList<Photo>();
        try {
            while (cursor.moveToNext()) {

                Photo photo = new Photo(
                        cursor.getString(urlIndex),
                        cursor.getString(titleIndex),
                        cursor.getInt(heightIndex),
                        cursor.getInt(widthIndex)
                );
                allPhotos.add(photo);
            }
        }
        finally {
            cursor.close();
        }
        PhotoAdapter mAdapter = new PhotoAdapter(allPhotos, LayoutInflater.from(mMainActivity));
        mMoviesRecyclerView.setAdapter(mAdapter);
    }

    @Override
    public void onLoaderReset(android.content.Loader<Cursor> loader) {
        // Nothing here
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager)  context.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
