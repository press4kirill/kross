#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_kirill_krossovertest_MainActivity_getFlickrAPIKey(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "b193fde00a3ed1e781187315dc1026d3";
    return env->NewStringUTF(hello.c_str());
}
