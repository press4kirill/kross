This is my Readme file describing the Android test I've written for Krossover

0. The app hits Flickr public API endpoint and gets info about 100 public photos, along with their titles, urls, width/height, etc.

1. It displays the photos' titles and sizes in a List, and upon clicking shows actual photos

2. Flickr API key is kept in the cpp file - as an example of where to keep sensitive data, since if hardcoded in the java source it can be easily discovered upon disassembling, even after obfuscation. Besides - it's just cool to use JNI :)

3. Download happens in a "headless" fragment, one of the many Android patterns allowing users to safely rotate the device. That way activity being killed and recreated on rotation doesn't affect the task.

4. Retrofit/GSon/Ormlite are used to download and store the feed. 

5. Loader pattern is used to access the sqlite-stored data of the feed,  the general idea of the pattern being - 
	a) (re)startLoader, whereby Loader goes to the DB
	b)  if something is found it is shown, if not it triggers the download, and then goes to a), (unless the feed came up empty)

      The header indicates whether the data came from the Net or from local sqlite. Downloading it once you can exit the app, cut off wi-fi and then restart the app again. Or you can just rotate the device - the activity is recreated, and the loader scoops the data from the local DB. To reload the data from the Net use the top menu option "Reload from Flickr" 
   

6. The brain of the app is the Controller class, which implements Controller/Presenter functionality. It deals with Loader, triggers headless fragment download, and the like.

7. The nice-to-have - "NYC Subway" menu option, which is available for portrait and named "Activate sensor". I take subway every day and while riding hold onto something, thereby forced to handle the phone with one hand only. So I included the pitch sensor - when activated, it allows scrolling with one hand, by tilting the phone back and forth. Helps when riding subway :)

8. Of course, given the time constraints some shortcuts were made, otherwise I would include: 
     a) downloading and displaying thumbnails while scrolling (involves handlers and passing ViewHolders around in "onBindViewHolder" to get thumbnails downloaded off the UI thread and not slowing down the scroll)
     b) Some Espresso tests

The attached apk was tested on several phones and emulators.

Thanks,
and looking forward,
Kirill Libin



