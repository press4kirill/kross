This is my Readme file describing the Android test I've written for IROKO
The project was developed on Android Studio 2.3.3, the  apk was tested on Samsung S6

0. API key is kept in the cpp file - as an example of where to keep sensitive data, since if hardcoded in the java source it can be easily discovered upon disassembling, even after obfuscation. Besides - it's just cool to use JNI :)

1. Download happens in a "headless" fragment, one of the many Android patterns allowing users to safely rotate the device. That way activity being killed and recreated on rotation doesn't affect the task.

2. Popular and Top Rated movies are fetched from different endpoints and displayed separately.

3. Loader pattern is used to access the sqlite-stored data of the feed,  the general idea of the pattern being - 
	a) (re)startLoader, whereby Loader goes to the DB
	b)  if something is found it is shown, if not it triggers the download, and then goes to a), (unless the feed came up empty)

      The header indicates whether the data came from the Net or from local sqlite. 

4. Controller class implements Controller/Presenter functionality. In reality it would be the brain of the app.

5. String data is cached in local DB (hence Ormlite), and Picasso takes care of caching images. 
Whether the data is gotten from Sqlite or Net is indicated in the headers.
Best way to test is - 
	a) have WIFI on, load some data, click on some movie and observe the poster (you may have to scroll textview to see all the data, including runtime and rating)
	b) kill the app (or reboot the phone), kill WIFI, start the app again - observe "loaded from Local SQLite" in the headers, click on the _SAME_ movie - observe the toast "No network, showing cached values", and see the data poster (thanks, Picasso :)

6. Scroll is infinite - once online, just keep scrolling! "Reload movies" option clears everything up and loads a new batch into each part.

7. Since the feed doesn't give any path to any mp4, I just chose some harmless bunny video.

8. Of course, since it's a Proof-Of-Concept test app, and given the time constraints, some shortcuts were made. (like, Picasso cache is not cleared)
(Emphatically) Overall it seems to do what it was designed to!


Thanks for your time,
and looking forward,
Kirill Libin



