#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_kirill_irokotest_MainActivity_getFlickrAPIKey(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "465333e63cabd7f8f86b359d42f3f653";
    return env->NewStringUTF(hello.c_str());
}
