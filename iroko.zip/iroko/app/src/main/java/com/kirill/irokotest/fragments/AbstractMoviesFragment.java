package com.kirill.irokotest.fragments;

import android.app.Fragment;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.kirill.irokotest.Controller;
import com.kirill.irokotest.MainActivity;
import com.kirill.irokotest.MovieDetailsActivity;
import com.kirill.irokotest.R;
import com.kirill.irokotest.adapters.MovieAdapter;
import com.kirill.irokotest.models.Movie;
import com.kirill.irokotest.utils.DatabaseHelper;
import com.kirill.irokotest.utils.Provider;

import java.util.ArrayList;
import java.util.List;

import static com.kirill.irokotest.Controller.isNetworkAvailable;
import static com.kirill.irokotest.MainActivity.NETWORK_UNAVAILABLE;
import static com.kirill.irokotest.utils.DatabaseHelper.PROJECTION;

abstract public class AbstractMoviesFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>  {

    private RecyclerView mMoviesRecyclerView;
    private ProgressBar mLoading;
    private TextView mHeaderTextView;
    private MainActivity mMainActivity;
    private Controller mController;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mMainActivity = (MainActivity)getActivity();
    }

    @Override
    public void onResume() {
        super.onResume();
        mController = mMainActivity.mController;

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup group, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.movies_fragment, null);
        mMoviesRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mLoading = (ProgressBar) view.findViewById(R.id.loading);
        mHeaderTextView = (TextView)view.findViewById(R.id.header_tv);

        mMoviesRecyclerView.setLayoutManager(new LinearLayoutManager(mMainActivity));
        getLoaderManager().initLoader(getType(), null, this);
        return view;
    }

    protected void hideHeader() {
        mMoviesRecyclerView.setVisibility(View.GONE);
        mHeaderTextView.setVisibility(View.GONE);
        mLoading.setVisibility(View.VISIBLE);
    }
    protected void showHeader(String header) {
        mMoviesRecyclerView.setVisibility(View.VISIBLE);
        mHeaderTextView.setVisibility(View.VISIBLE);
        mHeaderTextView.setText(header);
        mLoading.setVisibility(View.GONE);
    }
    public void onDownloadError(String err) {
        mMoviesRecyclerView.setVisibility(View.GONE);
        mHeaderTextView.setVisibility(View.VISIBLE);
        mHeaderTextView.setText(err);
        mLoading.setVisibility(View.GONE);
    }
    public void cleanUP() {
        OpenHelperManager.getHelper(mMainActivity, DatabaseHelper.class).clearDB(getType());
        MovieAdapter movieAdapter = ((MovieAdapter)mMoviesRecyclerView.getAdapter());
        if (movieAdapter != null) {
            movieAdapter.cleanUp();
        }
    }
    public void startMovieDetailsActivity(Movie movie) {
        int movieId = movie.id;
        String poster = movie.poster_path;
        String overview = movie.overview;
        String title = movie.title;

        Intent intent = new Intent(mMainActivity, MovieDetailsActivity.class);
        intent.putExtra(MovieDetailsActivity.MOVIE_ID, String.valueOf(movieId));
        intent.putExtra(MovieDetailsActivity.POSTER_ID, poster);
        intent.putExtra(MovieDetailsActivity.OVERVIEW, overview);
        intent.putExtra(MovieDetailsActivity.TITLE, title);
        mMainActivity.startActivity(intent);
    }
    @Override
    public android.content.Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return (new CursorLoader(mMainActivity, getUri(), PROJECTION, null, null, null));
    }
    abstract protected int getType();
    abstract protected Uri getUri();
    abstract protected String getTypeName();

    private boolean mGotFromNet = false;
    protected boolean getGotFromNet() {
        return mGotFromNet;
    }
    protected void setGotFromNet(boolean b) {
        mGotFromNet = b;
    }

    public void restartLoader() {
        mMainActivity.getLoaderManager().restartLoader(getType(), null, this);
    }

    @Override
    public void onLoadFinished(android.content.Loader<Cursor> loader,Cursor cursor) {

        boolean isNetAvailable = isNetworkAvailable(mMainActivity);
        if (cursor != null && cursor.getCount() > 1) {
            showAllMovies(cursor);
            showHeader(getTypeName() + (getGotFromNet() ? " movies loaded From The Internet " + cursor.getCount() : " movies loaded From Local SQLite " + cursor.getCount()));
            setGotFromNet(false);
        }
        else {
            if (!isNetAvailable) {
                showHeader(NETWORK_UNAVAILABLE);
                return;
            }

            loadFromTheNet();
        }
    }
    public void loadFromTheNet() {
        setGotFromNet(true);
        mController.loadFromTheNet(getType());
    }

    private int showAllMovies(Cursor cursor){

        int ret = 0;
        MovieAdapter movieAdapter = ((MovieAdapter)mMoviesRecyclerView.getAdapter());
        if (movieAdapter == null || movieAdapter.mMovies == null) {
            List<Movie> allMovies = new ArrayList<Movie>();
            ret = stuffMovies(allMovies, cursor);
            mMoviesRecyclerView.setAdapter(new MovieAdapter(this, allMovies, LayoutInflater.from(mMainActivity)));
        }
        else {
            List<Movie> allMovies = movieAdapter.mMovies;
            int start = allMovies.size() - 1;
            allMovies.clear();
            ret = stuffMovies(allMovies, cursor);
            int end = allMovies.size() - 1;
            if (start >= 0 && end >= 0) {
                movieAdapter.notifyItemRangeChanged(start, end);
            }
        }
        return ret;
    }


    private int stuffMovies(List<Movie> allMovies, Cursor cursor) {
        int typeIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_TYPE);
        int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
        int titleIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_TITLE);
        int overviewIndex =  cursor.getColumnIndex(DatabaseHelper.COLUMN_OVERVIEW);
        int posterIndex =  cursor.getColumnIndex(DatabaseHelper.COLUMN_POSTER_PATH);

        try {

            while (cursor.moveToNext()) {

                Movie movie = new Movie (
                        cursor.getInt(typeIndex),
                        cursor.getInt(idIndex),
                        cursor.getString(titleIndex),
                        cursor.getString(overviewIndex),
                        cursor.getString(posterIndex)
                );
                allMovies.add(movie);
            }
        }
        finally {
            cursor.close();
        }
        return (allMovies != null && allMovies.size() > 0 ? allMovies.get(allMovies.size() - 1).type : 0);
    }
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }
}
