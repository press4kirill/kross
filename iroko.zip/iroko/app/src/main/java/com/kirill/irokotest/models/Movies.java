package com.kirill.irokotest.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;


public class Movies {
    @SerializedName("page")
    public Integer mPages; // Not used

    @SerializedName("results")
    public List<Movie> mResultsList;

}
