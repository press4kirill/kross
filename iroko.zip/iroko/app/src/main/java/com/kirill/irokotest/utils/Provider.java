package com.kirill.irokotest.utils;


import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.j256.ormlite.android.apptools.OpenHelperManager;

public class Provider extends ContentProvider {

	private static final int POPULAR_MOVIES=1;
	private static final int TOP_RATED_MOVIES=2;

	public static final Uri POPULAR_MOVIES_CONTENT_URI =  Uri.parse("content://com.kirill.irokotest.test.Provider/" + POPULAR_MOVIES);
	public static final Uri TOP_RATED_MOVIES_CONTENT_URI =  Uri.parse("content://com.kirill.irokotest.test.Provider/" + TOP_RATED_MOVIES);

	@Override
	public String getType(Uri notUsed) {
		return null;
	}
	
	@Override
	public Uri insert(Uri url, ContentValues initialValues) {
	 return null;
	}
	
	@Override
	public int delete(Uri url, String where, String[] whereArgs) {
		return -1;
	}
	
	@Override
	public int update(Uri url, ContentValues values, String where,  String[] whereArgs) {
		return -1;
	}
	
	@Override
	public boolean onCreate() {
		return true;
	}

	@Override
	public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
		boolean pop =  (uri.getLastPathSegment().equals(String.valueOf(POPULAR_MOVIES)));
		Cursor cursor = OpenHelperManager.getHelper(getContext(), DatabaseHelper.class).loadMovies(pop);
		cursor.setNotificationUri(getContext().getContentResolver(), pop ? Provider.POPULAR_MOVIES_CONTENT_URI : Provider.TOP_RATED_MOVIES_CONTENT_URI);
		return cursor;
	}
}