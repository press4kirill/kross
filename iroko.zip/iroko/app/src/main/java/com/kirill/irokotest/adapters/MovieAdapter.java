package com.kirill.irokotest.adapters;


import android.graphics.Color;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kirill.irokotest.Controller;
import com.kirill.irokotest.R;
import com.kirill.irokotest.fragments.AbstractMoviesFragment;
import com.kirill.irokotest.models.Movie;
import java.util.List;

import static com.kirill.irokotest.Controller.isNetworkAvailable;
import static com.kirill.irokotest.MovieDetailsActivity.NO_NETWORK;



public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieHolder> {

    public class MovieHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        final private TextView mMovieTitleTextView;
        final private TextView mMovieOrderTextView;
        final private RelativeLayout mBkg;
        final private ProgressBar mProgressBar;
        private Movie mMovie;

        public MovieHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

            mMovieTitleTextView = (TextView) itemView.findViewById(R.id.movie_title);
            mMovieOrderTextView = (TextView) itemView.findViewById(R.id.movie_order);
            mBkg = (RelativeLayout) itemView.findViewById(R.id.movie_bkg);
            mProgressBar =  (ProgressBar) itemView.findViewById(R.id.loading_progress_bar);
        }

        public void bindMovie(Movie movie, int position) {
            mMovie = movie;

            mMovieTitleTextView.setText(mMovie.title);

            mMovieOrderTextView.setText("#" +  (position + 1));

            mBkg.setBackgroundColor(((position % 2) == 0) ? Color.LTGRAY : Color.WHITE);

            boolean b = (1+position) == mMovies.size();
            if (b) {
                if (!isNetworkAvailable(mMoviesFragment.getActivity())) {
                    Toast.makeText( mMoviesFragment.getActivity(), "Can not load up next batch, no network", Toast.LENGTH_SHORT).show();
                    return;
                }
                mProgressBar.setVisibility (View.VISIBLE );
                mMoviesFragment.restartLoader();
                mMoviesFragment.loadFromTheNet();
            }
            else {
                mProgressBar.setVisibility (View.GONE);
            }
            //mProgressBar.setVisibility (View.VISIBLE );
        }

        @Override
        public void onClick(View v) {
            mMoviesFragment.startMovieDetailsActivity(mMovie);
        }
    }


    public List<Movie> mMovies;
    final private LayoutInflater mLayoutInflater;
    private boolean mIsTaskExecuting = false;
    private AbstractMoviesFragment mMoviesFragment = null;
    public void cleanUp() {
        mMovies = null;
    }


    public MovieAdapter(AbstractMoviesFragment fragment, List<Movie> movies, LayoutInflater layoutInflater) {
        mMoviesFragment = fragment;
        mMovies = movies;
        mLayoutInflater = layoutInflater;
    }

    @Override
    public MovieHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = mLayoutInflater.inflate(R.layout.list_item_movie, parent, false);

        return new MovieHolder(view);
    }

    @Override
    public void onBindViewHolder(MovieHolder holder, int position) {
        Movie movie = mMovies.get(position);
        holder.bindMovie(movie, position);
    }

    @Override
    public int getItemCount() {
        return  mMovies == null ? 0 : mMovies.size();
    }



}

