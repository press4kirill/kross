package com.kirill.irokotest;

import android.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.kirill.irokotest.fragments.HeadlessFragment;

import static com.kirill.irokotest.Controller.isNetworkAvailable;


public class MainActivity extends AppCompatActivity  {


    private HeadlessFragment mFragment;
    public Controller mController;

    public static final String NETWORK_UNAVAILABLE = "Sorry, network unavaliable";
    public static final String FLICKER_URL = "https://api.themoviedb.org";
    //https://api.themoviedb.org/3/movie/popular?api_key=465333e63cabd7f8f86b359d42f3f653
    public static String FLICKER_API_KEY = "";
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FLICKER_API_KEY = getFlickrAPIKey();
        FragmentManager mMgr = getFragmentManager();
        mFragment = (HeadlessFragment) mMgr
                .findFragmentByTag(HeadlessFragment.TAG_HEADLESS_FRAGMENT);

        if (mFragment == null) {
            mFragment = new HeadlessFragment();
            mMgr.beginTransaction()
                    .add(mFragment, HeadlessFragment.TAG_HEADLESS_FRAGMENT)
                    .commit();
        }
        getLoaderManager(); //Weird bug https://stackoverflow.com/questions/12507617/android-loader-not-triggering-callbacks-on-screen-rotate
        mController = new Controller(this, mMgr, mFragment, (LinearLayout) findViewById(R.id.main_activity_view));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.menu_reload:
                if (mFragment.getIfTaskInProgress() ) {
                    Toast.makeText(this, "Wait, still loading...", Toast.LENGTH_SHORT).show();
                    return true;
                }
                if (!isNetworkAvailable(this)) {
                    Toast.makeText(this, NETWORK_UNAVAILABLE, Toast.LENGTH_SHORT).show();
                    return true;
                }
                mController.cleanUP();
                mController.restartLoader();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        mController.onMainActivityResume();

    }

    @Override
    public void onPause() {
        super.onPause();
        mController.onMainActivityPause();
    }

    public void onDownloadError(String err, int type) {
        mController.onDownloadError(err, type);
    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */

    public  native String getFlickrAPIKey();


}
