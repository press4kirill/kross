package com.kirill.irokotest.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.sql.SQLException;

import com.kirill.irokotest.R;

import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.kirill.irokotest.models.Movie;
import com.kirill.irokotest.models.Movies;


public class DatabaseHelper extends OrmLiteSqliteOpenHelper {

    private static final String TABLE_NAME = "movie";
    public static final String[] PROJECTION = new String[]{
            DatabaseHelper.COLUMN_TITLE,
            DatabaseHelper.COLUMN_TYPE,
            DatabaseHelper.COLUMN_ID,
            DatabaseHelper.COLUMN_OVERVIEW,
            DatabaseHelper.COLUMN_POSTER_PATH
    };

    public final static String COLUMN_TYPE =    "type";
    public final static String COLUMN_ID =    "id";
    public final static String COLUMN_TITLE =  "title";
    public final static String COLUMN_OVERVIEW = "overview";
    public final static String COLUMN_POSTER_PATH =  "poster_path";

    private static final String DATABASE_NAME = "movies.db";
    private static final int DATABASE_VERSION = 1;

    private Dao<Movie, Integer> movieDao = null;

    public DatabaseHelper(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION, R.raw.ormlite_config);
    }

    @Override
    public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
        try {
            TableUtils.createTable(connectionSource, Movie.class);
         } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, ConnectionSource connectionSource, int oldVersion, int newVersion) {
        // Nothing here
    }

    public Dao<Movie, Integer> getMovieDao() throws SQLException {
        if(movieDao == null) {
            movieDao = getDao(Movie.class);
        }
        return movieDao;
    }

    public void clearDB(int mode) {

        try {
            getMovieDao().updateRaw("DELETE FROM " + TABLE_NAME + " WHERE type = " + mode);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void commit() {
        getWritableDatabase().setTransactionSuccessful();
    }

    public Cursor loadMovies(boolean pop) {
        // Returning raw Cursor here for the ContentProvider's benefit
        try {
            return (getWritableDatabase().rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE type = " + (pop ? Movie.POPULAR_TYPE : Movie.TOP_RATED_TYPE), null));
        }
        catch (Exception e) {
            return null;
        }
    }
}
