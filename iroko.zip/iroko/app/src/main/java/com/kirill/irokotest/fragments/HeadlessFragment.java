package com.kirill.irokotest.fragments;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.Callable;

import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;


import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.misc.TransactionManager;
import com.kirill.irokotest.MainActivity;
import com.kirill.irokotest.models.Movie;
import com.kirill.irokotest.models.Movies;
import com.kirill.irokotest.utils.DatabaseHelper;

import retrofit.RestAdapter;
import retrofit.http.GET;
import retrofit.http.Path;
import retrofit.http.Query;
import static com.kirill.irokotest.MainActivity.FLICKER_API_KEY;
import static com.kirill.irokotest.utils.Provider.POPULAR_MOVIES_CONTENT_URI;
import static com.kirill.irokotest.utils.Provider.TOP_RATED_MOVIES_CONTENT_URI;


public class HeadlessFragment extends Fragment {

    public static final String TAG_HEADLESS_FRAGMENT = "TAG_HEADLESS_FRAGMENT";
    public static final String POPULAR = "popular";
    public static final String TOPRATED = "top_rated";

    public interface MoviesInterface  {
        @GET("/3/movie/{type}")
        Movies getMovies(@Path("type") String type, @Query("api_key") String api_key, @Query("page") int page);
    }

    private BackgroundTask mBackgroundTask;
    private boolean[] isTaskExecuting = new boolean[2];
    public boolean getIfTaskInProgress() {
        return isTaskExecuting[0] || isTaskExecuting[1];
    }

    /**
     * Called to do initial creation of a fragment.
     * This is called after onAttach(Activity) and before onCreateView(LayoutInflater, ViewGroup, Bundle)
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setRetainInstance(true);

    }

    public static int mPageNum = 0;
    private static class BackgroundTask extends AsyncTask<Void, Void, Void> {

        final private WeakReference<HeadlessFragment> mHeadlessFragment;
        final private Context mContext;
        boolean mSuccess = false;
        final private String mMode;
        final private int mType;

        @Override
        protected Void doInBackground(Void ... notused) {

            try {

                RestAdapter retrofit = new RestAdapter.Builder().setEndpoint(MainActivity.FLICKER_URL).build();
                MoviesInterface all = retrofit.create(MoviesInterface.class);

                final Movies ff =  all.getMovies(mMode, FLICKER_API_KEY, ++mPageNum);

                mSuccess = (ff != null);
                final DatabaseHelper helper = OpenHelperManager.getHelper(mContext, DatabaseHelper.class);
                final Dao<Movie, Integer> movieDao = helper.getMovieDao();
                TransactionManager.callInTransaction(helper.getConnectionSource(),
                        new Callable<Void>() {
                            public Void call() throws Exception {
                                for (Movie movie :  ff.mResultsList) {
                                    movie.type = mType;
                                    movieDao.create(movie);
                                }

                                mContext.getContentResolver().notifyChange((mType == Movie.POPULAR_TYPE ? POPULAR_MOVIES_CONTENT_URI : TOP_RATED_MOVIES_CONTENT_URI), null);
                                return null;
                            }
                });

            }
            catch (Exception ex) {
                ex.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            if (mHeadlessFragment != null && mHeadlessFragment.get() != null)
                mHeadlessFragment.get().updateExecutingStatus(false, mType);
            if (!mSuccess) {
                //KL727 pass which download
                ((MainActivity)mContext).onDownloadError("Download failed, please try later", mType);
            }
        }

        public BackgroundTask(HeadlessFragment hf, int type) {

            mType = type;
            mMode = (mType == Movie.POPULAR_TYPE ? POPULAR : TOPRATED);
            mHeadlessFragment = new WeakReference<HeadlessFragment>(hf);
            mContext = hf.getActivity();
        }

    }

    public void startBackgroundTask(int type) {

        if(!isTaskExecuting[type - 1]){
            mBackgroundTask = new BackgroundTask(this, type);
            mBackgroundTask.execute();
            isTaskExecuting[type - 1] = true;
        }
    }

    private void updateExecutingStatus(boolean isExecuting, int type){
        isTaskExecuting[type - 1] = isExecuting;
        mBackgroundTask = null;
        System.gc(); // humbly asking the system to cleanup ...garbage collecting...union job...probably won't do it :)
    }

}
