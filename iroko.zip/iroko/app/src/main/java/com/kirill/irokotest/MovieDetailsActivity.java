package com.kirill.irokotest;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kirill.irokotest.models.Movie;
import com.squareup.picasso.Picasso;

import retrofit.RestAdapter;
import retrofit.http.GET;
import retrofit.http.Path;
import retrofit.http.Query;

import static com.kirill.irokotest.Controller.isNetworkAvailable;
import static com.kirill.irokotest.MainActivity.NETWORK_UNAVAILABLE;

public class MovieDetailsActivity extends AppCompatActivity {
    public static final String MOVIE_ID = "MOVIE_ID";
    public static final String POSTER_ID = "POSTER_ID";
    public static final String OVERVIEW = "OVERVIEW";
    public static final String TITLE = "TITLE";


    public static final String NO_NETWORK = "No network, showing cached values";

    //https://api.themoviedb.org/3/movie/393729?api_key=465333e63cabd7f8f86b359d42f3f653
    public interface MovieDetailsInterface  {
        @GET("/3/movie/{movieId}")
        Movie getMovieDetails(@Path("movieId") String movieId, @Query("api_key") String api_key);
    }

    private String mMovieId;
    private String mPoster;
    private String mOverview;
    private String mTitle;
    private LinearLayout mLoading;
    private ImageView mPosterView;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_detail);

        mMovieId = getIntent().getStringExtra(MOVIE_ID);
        mPoster = getIntent().getStringExtra(POSTER_ID);
        mOverview = getIntent().getStringExtra(OVERVIEW);
        mTitle = getIntent().getStringExtra(TITLE);

        mLoading = (LinearLayout) findViewById(R.id.loading);
        mPosterView = (ImageView)findViewById(R.id.picture);

        textView = (TextView)findViewById(R.id.description);
        textView.setMovementMethod(new ScrollingMovementMethod());
    }

    @Override
    public void onResume() {
        super.onResume();

        Picasso.with(MovieDetailsActivity.this).load("https://image.tmdb.org/t/p/w500/" + mPoster).fit().centerCrop().into(mPosterView);

        if (!isNetworkAvailable(this)) {
             Toast.makeText( this, NO_NETWORK, Toast.LENGTH_SHORT).show();
             textView.setText(Html.fromHtml("<b>Cached values:</b><br>Title:<b>"+mTitle+"</b><br>Overview:<b>"+mOverview+"</b>"));
             return;
        }
        mLoading.setVisibility(View.VISIBLE);
        new FetchMovieDetailTask(mMovieId).execute();
    }

    public void playVideo(View notUsed) {
        if (!isNetworkAvailable(this)) {
            Toast.makeText( this, NETWORK_UNAVAILABLE, Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, VideoPlayActivity.class);
        startActivity(intent);

    }


//Displays: Poster Image, Title, Synopsis, duration and Rating.
    private class FetchMovieDetailTask extends AsyncTask<Void, Void, Void> {
        final private String mId;
        private Movie mMovie;


        public FetchMovieDetailTask(String id) {
            mId = id;
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                RestAdapter retrofit = new RestAdapter.Builder().setEndpoint(MainActivity.FLICKER_URL).build();
                MovieDetailsInterface all = retrofit.create(MovieDetailsInterface.class);
                mMovie =  all.getMovieDetails(mMovieId, MainActivity.FLICKER_API_KEY);

            } catch (Exception ex) {

                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void p) {
            try {
                mLoading.setVisibility(View.GONE);
              //  textView.setText(mMovie.runtime / 60 + ":" + mMovie.runtime % 60);
                textView.setText(Html.fromHtml("<br>Title:<b>"+mTitle+"</b><br>Overview:<b>"+mOverview+"</b>"+
                        "<br>Runtime:<b>"+(mMovie.runtime / 60 + ":" +
                        String.format("%02d",(mMovie.runtime % 60)) +"</b>, Rating:<b>"+mMovie.vote_average+"</b>")));
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }

    }
}
