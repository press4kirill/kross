package com.kirill.irokotest.fragments;

import android.net.Uri;
import android.util.Log;

import com.kirill.irokotest.models.Movie;
import com.kirill.irokotest.utils.Provider;


public class PopularMoviesFragment extends AbstractMoviesFragment {
    @Override
    protected int getType() {
        return Movie.POPULAR_TYPE;
    }

    @Override
    protected Uri getUri() {
        return Provider.POPULAR_MOVIES_CONTENT_URI;
    }

    @Override
    protected String getTypeName() {
        return "Popular";
    }

}
