package com.kirill.irokotest.fragments;

import android.app.Fragment;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.kirill.irokotest.MainActivity;
import com.kirill.irokotest.R;
import com.kirill.irokotest.adapters.MovieAdapter;
import com.kirill.irokotest.models.Movie;
import com.kirill.irokotest.utils.DatabaseHelper;
import com.kirill.irokotest.utils.Provider;

public class TopRatedMoviesFragment extends AbstractMoviesFragment {
    @Override
    protected int getType() {
        return Movie.TOP_RATED_TYPE;
    }

    @Override
    protected Uri getUri() {
        return Provider.TOP_RATED_MOVIES_CONTENT_URI;
    }

    @Override
    protected String getTypeName() {
        return "Top Rated";
    }
}
