package com.kirill.irokotest;


import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.app.LoaderManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.content.CursorLoader;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;

import com.kirill.irokotest.fragments.HeadlessFragment;
import com.kirill.irokotest.fragments.PopularMoviesFragment;
import com.kirill.irokotest.fragments.TopRatedMoviesFragment;
import com.kirill.irokotest.models.Movie;

import static android.content.Context.CONNECTIVITY_SERVICE;
import static com.kirill.irokotest.MainActivity.NETWORK_UNAVAILABLE;
import static com.kirill.irokotest.utils.DatabaseHelper.PROJECTION;

public class Controller {
    final private MainActivity mMainActivity;
    public HeadlessFragment mHeadlessFragment;
    final private PopularMoviesFragment mPopularMoviesFragment;
    final private TopRatedMoviesFragment mTopRatedMoviesFragment;


    public Controller(MainActivity ma, FragmentManager mgr, HeadlessFragment hf, View view) {
        mMainActivity = ma;
        mHeadlessFragment = hf;
        mPopularMoviesFragment = (PopularMoviesFragment)mgr.findFragmentById(R.id.popular_movies_fragment);
        mTopRatedMoviesFragment = (TopRatedMoviesFragment)mgr.findFragmentById(R.id.toprated_movies_fragment);
    }

    public void onMainActivityResume() {
    }
    public void cleanUP() {
        mPopularMoviesFragment.cleanUP();
        mTopRatedMoviesFragment.cleanUP();
    }

    public void onDownloadError(String err, int type) {
        if (type == Movie.POPULAR_TYPE) {
            mPopularMoviesFragment.onDownloadError(err);
        }
        else if (type == Movie.TOP_RATED_TYPE) {
            mTopRatedMoviesFragment.onDownloadError(err);
        }
    }

    public void loadFromTheNet(int type) {
        if (mHeadlessFragment != null && isNetworkAvailable(mMainActivity)) {
            mHeadlessFragment.startBackgroundTask(type);
        }
    }
    public void restartLoader() {
        mTopRatedMoviesFragment.restartLoader();
        mPopularMoviesFragment.restartLoader();

    }

    public void onMainActivityPause() {
        mMainActivity.getLoaderManager().destroyLoader(0);
    }

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager)  context.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


}
